function image(){
alert("Don't touch me!")
alert("Touch me again")
}

var app = new Vue({
  el: '#app',
  data: {
    todos: [
      { text: 'Name' },
      { text: 'Favorite Fruit' },
      { text: 'Country' }
    ]
  }
})



function total(){
var INPUT1=document.getElementById('INPUT1').value;
var INPUT2=document.getElementById('INPUT2').value;
var INPUT3=document.getElementById('INPUT3').value;
var total=Number(INPUT1)+Number(INPUT2)+Number(INPUT3);
docment.getElementById("result").innerHTML=total;
var aver =(Number(INPUT1)+Number(INPUT2)+Number(INPUT3)/3);
docment.getElementById("average").innerHTML=aver;
}

let x = 80;
let y = 78;
let z = 65;
let total = x + y + z;
let avg = total/3;
document.getElementById("result").innerHTML = "The scores are" + x + ", " + y + " and " + z +". Average of the scores is: " + avg;