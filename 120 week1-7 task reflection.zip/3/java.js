let str = "Watermelon, Banana, Orange";
document.getElementById("1").innerHTML = str.slice(-15,-8);
document.getElementById("2").innerHTML = str.substring(0,10);
document.getElementById("3").innerHTML = str.substring(19,7);
document.getElementById("6").innerHTML = str.toUpperCase();
document.getElementById("7").innerHTML = str.toLowerCase();

let str2 = "Watermelon";
document.getElementById("4").innerHTML = str2.length;

function change() {
  let text = document.getElementById("5").innerHTML;
  document.getElementById("5").innerHTML = text.replace("Bananas","Watermelon");
}

document.getElementById("8").innerHTML = str.charAt(5);
document.getElementById("9").innerHTML = str.indexOf("m");

let str3 = ["Watermelon", "Banana", "Orange"];
document.getElementById("10").innerHTML = str3.join("/");

var date = new Date();
document.getElementById("11").innerHTML = date; 
document.getElementById("12").innerHTML = date.getFullYear(); 
