var selected = new Vue({
    el:"#select",
    data:{
    selected: 'A',
    options:[
        {text:'Sweet', vaule:'A'},
        {text:'Sour', vaule:'B'},
        {text:'Bitter', vaule:'C'},
        {text:'Hot', vaule:'D'},
        {text:'Cold', vaule:'E'},
        {text:'Fried', vaule:'F'},
        {text:'Roast', vaule:'G'},
        {text:'Salty', vaule:'H'},
    ]
        
    }
})

Vue.createApp({
  data() {
    return {
      checkedNames: [],
    }
  }
}).mount('#v-model-multiple-checkboxes')

var form = new Vue({
    el:"#userform",
    data:{
        username: '',
        password: '',
        email: '',
},
    methods:{
        checkInput: function() {
            var str='';
            if (this.username) {
                str = str +"username: " + this.username;
            }
            if (this.password) {
                str = str +"password: " + this.password;
            }
            if (this.email) {
                str = str +"email: " + this.email;
            }
            if(str) {
                alert(str)
            } else (
                alert("please input required info")
            )

            }
            }
        
})

export default{
name: "Vmodel",
data: () => {
return {
inputValue: ''
}
}
}