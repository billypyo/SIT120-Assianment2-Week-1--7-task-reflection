var app2 = new Vue({
    el: '#app-2',
    data: {
      message: 'You loaded this page on ' + new Date().toLocaleString()
    }
  })
  
  var c = document.getElementById("myCanvas");
  var ctx = c.getContext("2d");
  ctx.font = "30px Arial";
  ctx.strokeText("Bananas",10,50);
  
  var app = new Vue({
    el: '#app',
    data: {
      message: 'Fruits are an important part of a healthy eating pattern and the source of many vital nutrients, including potassium, folate, and antioxidants including polyphenols. Fruit such as blueberries, cranberries, strawberries and citrus also contain phytochemicals that are being studied for their added health benefits.'
    }
  })
  
  var app3 = new Vue({
    el: '#app-3',
    data: {
      seen: true
    }
  })
  
  var app4 = new Vue({
    el: '#app-4',
    data: {
      todos: [
        { text: 'help manage blood pressure' },
        { text: 'reduce strain on the cardiovascular system' },
        { text: 'prevent Cancer' },
        { text: 'support heart health'},
        { text: 'lower blood sugar'},
        { text: 'reduce the risk for diabetes'},
        { text: 'prevent wheezing in children with asthma'}
        
      ]
    }
  })